import { useState } from 'react';
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Select, SelectItem } from "./components/ui/select";

const slots = [
  "Book of Dead", "Wanted Dead or a Wild", "Gates of Olympus", "Sugar Rush",
  "Sweet Bonanza", "The Dog House", "Razor Shark", "Legacy of Dead",
  "Money Train 4", "Chaos Crew 2"
];

export default function SlotLogger() {
  const [logs, setLogs] = useState([]);
  const [slot, setSlot] = useState("Book of Dead");
  const [bet, setBet] = useState(0.2);
  const [win, setWin] = useState(0);
  const [bonusSymbol, setBonusSymbol] = useState("");
  const [bonusMultiplier, setBonusMultiplier] = useState(0);
  const [bonusType, setBonusType] = useState("");

  const addLog = () => {
    const newLog = {
      slot,
      bet: parseFloat(bet),
      win: parseFloat(win),
      bonusSymbol,
      bonusMultiplier: parseFloat(bonusMultiplier),
      bonusType,
      time: new Date().toLocaleString(),
    };
    setLogs([newLog, ...logs]);
    setWin(0);
    setBonusSymbol("");
    setBonusMultiplier(0);
    setBonusType("");
  };

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <Card>
        <CardContent className="space-y-2 p-4">
          <Select value={slot} onValueChange={setSlot}>
            {slots.map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </Select>
          <Input type="number" step="0.01" value={bet} onChange={(e) => setBet(e.target.value)} placeholder="Ставка (USDT / TON)" />
          <Input type="number" step="0.01" value={win} onChange={(e) => setWin(e.target.value)} placeholder="Выигрыш" />
          <Input value={bonusSymbol} onChange={(e) => setBonusSymbol(e.target.value)} placeholder="Символ бонуса (если есть)" />
          <Input type="number" value={bonusMultiplier} onChange={(e) => setBonusMultiplier(e.target.value)} placeholder="Множитель бонуса (x185)" />
          <Input value={bonusType} onChange={(e) => setBonusType(e.target.value)} placeholder="Тип бонуса (FS, respin, ретриггер)" />
          <Button className="w-full" onClick={addLog}>Записать спин</Button>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {logs.map((log, index) => (
          <Card key={index} className="bg-gray-100">
            <CardContent className="p-2 text-sm">
              🎰 <strong>{log.slot}</strong> — {log.bet} USDT / TON → 💰 {log.win}<br/>
              {log.bonusSymbol && <>🧿 Символ: {log.bonusSymbol}, x{log.bonusMultiplier}, Тип: {log.bonusType}<br/></>}
              🕓 {log.time}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
